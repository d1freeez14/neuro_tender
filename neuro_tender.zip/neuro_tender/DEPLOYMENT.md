# Руководство по развертыванию Neuro Tender

## Требования к системе

### Минимальные требования
- CPU: 4 ядра
- RAM: 8GB
- Диск: 50GB SSD
- ОС: Ubuntu 20.04+ / CentOS 8+ / Windows 10+

### Рекомендуемые требования
- CPU: 8 ядер
- RAM: 16GB
- Диск: 100GB NVMe SSD
- ОС: Ubuntu 22.04 LTS

## Установка зависимостей

### Ubuntu/Debian

```bash
# Обновление системы
sudo apt update && sudo apt upgrade -y

# Установка Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh
sudo usermod -aG docker $USER

# Установка Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# Установка Python зависимостей
sudo apt install -y python3.11 python3.11-pip python3.11-venv
sudo apt install -y tesseract-ocr tesseract-ocr-rus tesseract-ocr-kaz
```

### CentOS/RHEL

```bash
# Установка Docker
sudo yum install -y yum-utils
sudo yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
sudo yum install -y docker-ce docker-ce-cli containerd.io
sudo systemctl start docker
sudo systemctl enable docker

# Установка Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose
```

## Развертывание

### 1. Клонирование репозитория

```bash
git clone <repository-url>
cd neuro_tender
```

### 2. Настройка переменных окружения

```bash
cp cfg/env.example .env
nano .env  # Отредактируйте настройки
```

### 3. Запуск с Docker

```bash
cd cfg
docker-compose up -d
```

### 4. Проверка статуса

```bash
docker-compose ps
docker-compose logs -f
```

## Настройка модели ИИ

### Загрузка модели Ollama

```bash
# Подключение к контейнеру
docker exec -it neuro_tender_ollama bash

# Загрузка модели
ollama pull llama3:8b-instruct-q5_K_M

# Проверка
ollama list
```

### Альтернативные модели

```bash
# Более быстрая модель
ollama pull llama3:8b-instruct-q4_K_M

# Более точная модель
ollama pull llama3:8b-instruct-q6_K
```

## Мониторинг

### Логи

```bash
# Просмотр логов приложения
docker-compose logs -f dgpycrw

# Просмотр логов Ollama
docker-compose logs -f dgollama

# Логи в файлах
tail -f log/logs.log
```

### Статистика ресурсов

```bash
# Использование ресурсов
docker stats

# Место на диске
docker system df
```

## Обслуживание

### Обновление

```bash
# Остановка сервисов
docker-compose down

# Обновление кода
git pull

# Пересборка образов
docker-compose build --no-cache

# Запуск
docker-compose up -d
```

### Очистка

```bash
# Очистка неиспользуемых образов
docker system prune -a

# Очистка данных приложения
cd crw
python remover.py
```

### Резервное копирование

```bash
# Создание бэкапа данных
tar -czf backup_$(date +%Y%m%d).tar.gz cnt/ log/

# Восстановление
tar -xzf backup_20240101.tar.gz
```

## Безопасность

### Настройка файрвола

```bash
# Ubuntu/Debian
sudo ufw allow 80
sudo ufw allow 11434
sudo ufw enable

# CentOS/RHEL
sudo firewall-cmd --permanent --add-port=80/tcp
sudo firewall-cmd --permanent --add-port=11434/tcp
sudo firewall-cmd --reload
```

### SSL сертификаты

```bash
# Установка Certbot
sudo apt install certbot

# Получение сертификата
sudo certbot certonly --standalone -d your-domain.com
```

## Масштабирование

### Горизонтальное масштабирование

```bash
# Запуск нескольких экземпляров
docker-compose up -d --scale dgpycrw=3
```

### Настройка балансировщика

```nginx
upstream neuro_tender {
    server localhost:8001;
    server localhost:8002;
    server localhost:8003;
}

server {
    listen 80;
    location / {
        proxy_pass http://neuro_tender;
    }
}
```

## Устранение неполадок

### Проблемы с памятью

```bash
# Увеличение лимитов Docker
echo '{"default-ulimits":{"memlock":{"Hard":-1,"Name":"memlock","Soft":-1}}}' | sudo tee /etc/docker/daemon.json
sudo systemctl restart docker
```

### Проблемы с сетью

```bash
# Проверка сетевых подключений
docker network ls
docker network inspect neuro_tender_network
```

### Проблемы с диском

```bash
# Очистка Docker
docker system prune -a --volumes

# Очистка логов
sudo journalctl --vacuum-time=7d
```

## Автоматизация

### Systemd сервис

```ini
[Unit]
Description=Neuro Tender
Requires=docker.service
After=docker.service

[Service]
Type=oneshot
RemainAfterExit=yes
WorkingDirectory=/path/to/neuro_tender/cfg
ExecStart=/usr/local/bin/docker-compose up -d
ExecStop=/usr/local/bin/docker-compose down
TimeoutStartSec=0

[Install]
WantedBy=multi-user.target
```

### Cron задачи

```bash
# Добавление в crontab
crontab -e

# Запуск каждые 6 часов
0 */6 * * * cd /path/to/neuro_tender/cfg && docker-compose restart dgpycrw

# Очистка логов еженедельно
0 2 * * 0 cd /path/to/neuro_tender/crw && python remover.py
```
